gammurc_file="/home/pi/.gammurc"

PIN="0000"

contacts=["+15186760367"]

#source_list=[] will be the one defined in key_WAZIUP.py