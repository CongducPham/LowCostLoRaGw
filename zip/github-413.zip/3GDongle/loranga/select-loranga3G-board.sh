#!/bin/sh

echo "1" > loranga3G.txt