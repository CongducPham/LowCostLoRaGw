#!/bin/sh

rm -rf use_loranga_SMS_on_boot.txt