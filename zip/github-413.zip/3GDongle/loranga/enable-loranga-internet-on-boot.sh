#!/bin/sh

echo "1" > use_loranga_internet_on_boot.txt