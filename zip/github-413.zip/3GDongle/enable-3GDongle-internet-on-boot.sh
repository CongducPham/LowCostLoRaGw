#!/bin/sh

echo "1" > use_3GDongle_internet_on_boot.txt